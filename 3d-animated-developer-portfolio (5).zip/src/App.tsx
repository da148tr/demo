import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence, useScroll, useInView, useSpring } from 'framer-motion';
import emailjs from '@emailjs/browser';
import {
  Menu, X, Mail, Code, Rocket, ChevronDown,
  Send, MapPin, Phone, Sparkles, Award, Users,
  Heart, ArrowRight, Languages, Star, Monitor, Server,
  Palette, Coffee, Zap, Eye, MessageCircle,
  Calendar, Briefcase, GraduationCap,
  Sun, Moon, ArrowUp, CheckCircle, Play, Shield, Cpu,
  Smartphone, Database, GitBranch, Layout,
  User, FileText, AlertCircle, Globe, Clock, Headphones,
  ExternalLink,
} from 'lucide-react';

const PROFILE_IMAGE = '/images/daniel-profile.jpg';

// ===== SVG ICONS =====
const GithubIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>
);
const LinkedinIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
);
const TelegramIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>
);

// ===== TRANSLATIONS =====
const translations = {
  en: {
    nav: { home: 'Home', about: 'About', skills: 'Skills', projects: 'Projects', experience: 'Experience', contact: 'Contact' },
    hero: { greeting: "Hello, I'm", name: 'Daniel Tsigu', title: 'Full Stack Web Developer', subtitle: 'Crafting stunning digital experiences from Asella, Ethiopia 🇪🇹 — Building modern websites with cutting-edge technologies, 3D animations & creative design', cta1: 'View My Work', cta2: 'Get In Touch', available: '✨ Available for freelance work', download: 'Download CV' },
    about: { title: 'About Me', subtitle: 'A passionate developer from Ethiopia turning ideas into reality', description1: 'I am Daniel Tsigu, a creative full-stack web developer based in Asella, Ethiopia 🇪🇹. With a passion for building beautiful, functional websites and applications, I specialize in modern web technologies including HTML, CSS, JavaScript, React, and more.', description2: 'I bring ideas to life through clean code, stunning animations, and thoughtful design. Every project I take on is a chance to push boundaries and create something extraordinary. Let\'s build the future of the web together!', location: 'Based in Asella, Ethiopia', stats: { projects: 'Projects', clients: 'Clients', years: 'Years Exp.', awards: 'Awards' } },
    skills: { title: 'My Skills', subtitle: 'Technologies and tools I master', categories: { frontend: 'Frontend', backend: 'Backend', design: 'Design', tools: 'Tools' } },
    projects: { title: 'Featured Projects', subtitle: 'Some of my best work', viewAll: 'View All Projects', live: 'Live Demo', code: 'View Code', all: 'All', web: 'Web Apps', mobile: 'Mobile', design: 'Design' },
    services: { title: 'My Services', subtitle: 'What I can do for you' },
    experience: { title: 'Experience & Education', subtitle: 'My professional journey' },
    testimonials: { title: 'Client Reviews', subtitle: 'What people say about my work' },
    contact: { title: 'Get In Touch', subtitle: "Let's work together on your next project", name: 'Your Name', email: 'Your Email', subject: 'Subject', message: 'Your Message', send: 'Send Message', sending: 'Sending...', sent: 'Message Sent Successfully!', error: 'Failed to send. Try again!', location: 'Location', phone: 'Phone', emailLabel: 'Email', followMe: 'Follow Me', letsConnect: "Let's Connect", reachOut: 'Reach out and I will get back to you within 24 hours.', chatNow: 'Chat with me now', responseTime: 'Response within 24h', availableHours: 'Available 9AM - 9PM EAT' },
    footer: { rights: 'All rights reserved.', madeWith: 'Made with', fromEthiopia: 'from Ethiopia 🇪🇹' }
  },
  am: {
    nav: { home: 'መነሻ', about: 'ስለ እኔ', skills: 'ችሎታዎች', projects: 'ፕሮጀክቶች', experience: 'ልምድ', contact: 'አግኙኝ' },
    hero: { greeting: 'ሰላም፣ እኔ', name: 'ዳንኤል ፅጉ', title: 'ፉል ስታክ ዌብ ዴቨሎፐር', subtitle: 'ከአሰላ ኢትዮጵያ 🇪🇹 — ዘመናዊ ድር ጣቢያዎችን በዘመናዊ ቴክኖሎጂ ፣ 3D አኒሜሽን እና የፈጠራ ዲዛይን ስገነባ', cta1: 'ስራዬን ይመልከቱ', cta2: 'ያግኙኝ', available: '✨ ለፍሪላንስ ስራ ዝግጁ ነኝ', download: 'ሲቪ አውርድ' },
    about: { title: 'ስለ እኔ', subtitle: 'ሃሳቦችን ወደ እውነታ የሚቀይር ከኢትዮጵያ ፈጣሪ ዴቨሎፐር', description1: 'እኔ ዳንኤል ፅጉ ነኝ፣ በአሰላ ኢትዮጵያ 🇪🇹 ውስጥ የምገኝ ፈጣሪ ፉል-ስታክ ዌብ ዴቨሎፐር ነኝ። ቆንጆ እና ተግባራዊ ድር ጣቢያዎችን እና መተግበሪያዎችን ለመገንባት ባለኝ ፍቅር HTML ፣ CSS ፣ JavaScript ፣ React እና ሌሎችም ዘመናዊ ቴክኖሎጂዎች ላይ ልዩ ነኝ።', description2: 'ሃሳቦችን በንጹህ ኮድ ፣ በሚያስደንቁ አኒሜሽኖች እና በጥንቃቄ ዲዛይን ወደ ህይወት አመጣለሁ።', location: 'መኖሪያ: አሰላ, ኢትዮጵያ', stats: { projects: 'ፕሮጀክቶች', clients: 'ደንበኞች', years: 'ዓመታት', awards: 'ሽልማቶች' } },
    skills: { title: 'ችሎታዎቼ', subtitle: 'የምጠቀምባቸው ቴክኖሎጂዎች እና መሳሪያዎች', categories: { frontend: 'ፍሮንትኤንድ', backend: 'ባክኤንድ', design: 'ዲዛይን', tools: 'መሳሪያዎች' } },
    projects: { title: 'ታዋቂ ፕሮጀክቶች', subtitle: 'ከምርጥ ስራዎቼ', viewAll: 'ሁሉንም ፕሮጀክቶች ይመልከቱ', live: 'ቀጥታ ማሳያ', code: 'ኮድ ይመልከቱ', all: 'ሁሉም', web: 'ዌብ', mobile: 'ሞባይል', design: 'ዲዛይን' },
    services: { title: 'አገልግሎቶቼ', subtitle: 'ለእርስዎ ምን ማድረግ እችላለሁ' },
    experience: { title: 'ልምድ እና ትምህርት', subtitle: 'የሙያ ጉዞዬ' },
    testimonials: { title: 'የደንበኞች ግምገማ', subtitle: 'ስለ ስራዬ ሰዎች ምን ይላሉ' },
    contact: { title: 'ያግኙኝ', subtitle: 'በቀጣዩ ፕሮጀክትዎ ላይ አብረን እንስራ', name: 'ስมዎ', email: 'ኢሜልዎ', subject: 'ርዕስ', message: 'መልእክትዎ', send: 'መልእክት ላክ', sending: 'በመላክ ላይ...', sent: 'መልእክት በተሳካ ሁኔታ ተልኳል!', error: 'መላክ አልተሳካም!', location: 'አድራሻ', phone: 'ስልክ', emailLabel: 'ኢሜል', followMe: 'ተከተሉኝ', letsConnect: 'እንገናኝ', reachOut: 'ያግኙኝ በ24 ሰዓት ውስጥ ምላሽ እሰጣለሁ።', chatNow: 'አሁን ያወሩኝ', responseTime: 'በ24 ሰዓት ውስጥ ምላሽ', availableHours: '9AM - 9PM EAT ዝግጁ ነኝ' },
    footer: { rights: 'መብቱ በሙሉ የተጠበቀ ነው።', madeWith: 'በ', fromEthiopia: 'ከኢትዮጵያ 🇪🇹' }
  },
  fr: {
    nav: { home: 'Accueil', about: 'À Propos', skills: 'Compétences', projects: 'Projets', experience: 'Expérience', contact: 'Contact' },
    hero: { greeting: 'Bonjour, je suis', name: 'Daniel Tsigu', title: 'Développeur Web Full Stack', subtitle: "Création d'expériences numériques depuis Asella, Éthiopie 🇪🇹 — Sites web modernes avec animations 3D et design créatif", cta1: 'Voir Mon Travail', cta2: 'Me Contacter', available: '✨ Disponible pour du freelance', download: 'Télécharger CV' },
    about: { title: 'À Propos', subtitle: "Un développeur passionné d'Éthiopie", description1: "Je suis Daniel Tsigu, développeur web full-stack créatif basé à Asella, Éthiopie 🇪🇹. Passionné par la création de sites web beaux et fonctionnels, je me spécialise dans les technologies modernes.", description2: "Je donne vie aux idées grâce à un code propre, des animations époustouflantes et un design réfléchi.", location: 'Basé à Asella, Éthiopie', stats: { projects: 'Projets', clients: 'Clients', years: "Années d'Exp.", awards: 'Prix' } },
    skills: { title: 'Mes Compétences', subtitle: 'Technologies et outils que je maîtrise', categories: { frontend: 'Frontend', backend: 'Backend', design: 'Design', tools: 'Outils' } },
    projects: { title: 'Projets en Vedette', subtitle: 'Certains de mes meilleurs travaux', viewAll: 'Voir Tous les Projets', live: 'Démo', code: 'Code', all: 'Tous', web: 'Web', mobile: 'Mobile', design: 'Design' },
    services: { title: 'Mes Services', subtitle: 'Ce que je peux faire pour vous' },
    experience: { title: 'Expérience & Formation', subtitle: 'Mon parcours professionnel' },
    testimonials: { title: 'Avis Clients', subtitle: 'Ce que les gens disent de mon travail' },
    contact: { title: 'Me Contacter', subtitle: 'Travaillons ensemble sur votre prochain projet', name: 'Votre Nom', email: 'Votre Email', subject: 'Sujet', message: 'Votre Message', send: 'Envoyer le Message', sending: 'Envoi en cours...', sent: 'Message envoyé avec succès!', error: "Échec de l'envoi!", location: 'Localisation', phone: 'Téléphone', emailLabel: 'Email', followMe: 'Suivez-moi', letsConnect: 'Connectons-nous', reachOut: 'Contactez-moi et je vous répondrai dans les 24 heures.', chatNow: 'Discuter maintenant', responseTime: 'Réponse en 24h', availableHours: 'Disponible 9h - 21h EAT' },
    footer: { rights: 'Tous droits réservés.', madeWith: 'Fait avec', fromEthiopia: "depuis l'Éthiopie 🇪🇹" }
  }
};
type LangKey = keyof typeof translations;

// ===== CUSTOM CURSOR =====
function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const [hovering, setHovering] = useState(false);

  useEffect(() => {
    const move = (e: MouseEvent) => {
      if (cursorRef.current) {
        cursorRef.current.style.left = e.clientX + 'px';
        cursorRef.current.style.top = e.clientY + 'px';
      }
      if (dotRef.current) {
        dotRef.current.style.left = e.clientX + 'px';
        dotRef.current.style.top = e.clientY + 'px';
      }
    };
    const over = () => setHovering(true);
    const out = () => setHovering(false);
    window.addEventListener('mousemove', move);
    document.querySelectorAll('a, button, .card, input, textarea, select').forEach(el => {
      el.addEventListener('mouseenter', over);
      el.addEventListener('mouseleave', out);
    });
    return () => {
      window.removeEventListener('mousemove', move);
    };
  }, []);

  return (
    <>
      <div ref={cursorRef} className={`custom-cursor hidden md:block ${hovering ? 'hovering' : ''}`} />
      <div ref={dotRef} className="cursor-dot hidden md:block" />
    </>
  );
}

// ===== WAVE DIVIDER =====
function WaveDivider({ color = '#ffffff', flip = false, darkColor = '#0a0a1a' }: { color?: string; flip?: boolean; darkColor?: string }) {
  return (
    <div className={flip ? 'wave-divider-top' : 'wave-divider'}>
      <svg viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z">
          <animate attributeName="fill" values={`${color};${color}`} dur="0s" fill="freeze" />
        </path>
      </svg>
      <style>{`
        body.dark .wave-divider path, body.dark .wave-divider-top path { fill: ${darkColor} !important; }
        body:not(.dark) .wave-divider path, body:not(.dark) .wave-divider-top path { fill: ${color} !important; }
      `}</style>
    </div>
  );
}

// ===== ANIMATED BACKGROUND =====
function AnimatedBackground({ dark }: { dark: boolean }) {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <motion.div animate={{ scale: [1, 1.3, 1], rotate: [0, 180, 360] }} transition={{ duration: 20, repeat: Infinity }} className="absolute -top-1/4 -right-1/4 w-[600px] h-[600px] rounded-full animate-morph" style={{ background: dark ? 'radial-gradient(circle, rgba(99,102,241,0.15), transparent 70%)' : 'radial-gradient(circle, rgba(99,102,241,0.12), transparent 70%)' }} />
      <motion.div animate={{ scale: [1.2, 1, 1.2], rotate: [360, 180, 0] }} transition={{ duration: 25, repeat: Infinity }} className="absolute -bottom-1/4 -left-1/4 w-[500px] h-[500px] rounded-full animate-morph" style={{ background: dark ? 'radial-gradient(circle, rgba(0,155,58,0.1), transparent 70%)' : 'radial-gradient(circle, rgba(0,155,58,0.08), transparent 70%)', animationDelay: '2s' }} />
      <motion.div animate={{ x: [0, 100, 0], y: [0, -60, 0] }} transition={{ duration: 15, repeat: Infinity }} className="absolute top-1/3 left-1/4 w-[400px] h-[400px] rounded-full animate-morph" style={{ background: dark ? 'radial-gradient(circle, rgba(236,72,153,0.1), transparent 70%)' : 'radial-gradient(circle, rgba(236,72,153,0.06), transparent 70%)', animationDelay: '4s' }} />
      <div className="absolute inset-0" style={{ backgroundImage: dark ? 'radial-gradient(rgba(99,102,241,0.08) 1px, transparent 1px)' : 'radial-gradient(rgba(99,102,241,0.05) 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div key={i} className="absolute rounded-full" style={{ left: `${(i * 5.3) % 100}%`, top: `${(i * 7.7) % 100}%`, width: `${3 + (i % 4) * 2}px`, height: `${3 + (i % 4) * 2}px`, background: ['#009B3A', '#FCDD09', '#EF2118', '#6366f1', '#ec4899', '#06b6d4'][i % 6], opacity: 0.4 }}
          animate={{ y: [0, -60 - (i % 3) * 30, 0], x: [0, (i % 2 ? 20 : -20), 0], opacity: [0, 0.6, 0], scale: [0.5, 1.2, 0.5] }}
          transition={{ duration: 4 + (i % 5), repeat: Infinity, delay: (i * 0.3) % 3 }}
        />
      ))}
    </div>
  );
}

// ===== 3D TILT CARD =====
function Tilt3DCard({ children, className = '', intensity = 8 }: { children: React.ReactNode; className?: string; intensity?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState('perspective(1000px) rotateX(0deg) rotateY(0deg)');
  const [glare, setGlare] = useState({ x: 50, y: 50, opacity: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const rx = ((y - cy) / cy) * -intensity;
    const ry = ((x - cx) / cx) * intensity;
    setTransform(`perspective(1000px) rotateX(${rx}deg) rotateY(${ry}deg) scale3d(1.03,1.03,1.03)`);
    setGlare({ x: (x / rect.width) * 100, y: (y / rect.height) * 100, opacity: 0.15 });
  };
  const handleMouseLeave = () => {
    setTransform('perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1,1,1)');
    setGlare({ x: 50, y: 50, opacity: 0 });
  };

  return (
    <div ref={ref} onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave} className={className}
      style={{ transform, transition: 'transform 0.4s cubic-bezier(0.03,0.98,0.52,0.99)', transformStyle: 'preserve-3d', position: 'relative' }}>
      {children}
      <div style={{ position: 'absolute', inset: 0, borderRadius: 'inherit', background: `radial-gradient(circle at ${glare.x}% ${glare.y}%, rgba(255,255,255,${glare.opacity}), transparent 60%)`, pointerEvents: 'none', transition: 'opacity 0.3s ease' }} />
    </div>
  );
}

// ===== TYPING EFFECT =====
function TypingText({ texts, className = '' }: { texts: string[]; className?: string }) {
  const [currentText, setCurrentText] = useState('');
  const [textIndex, setTextIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const text = texts[textIndex];
    const timeout = setTimeout(() => {
      if (!isDeleting) {
        setCurrentText(text.substring(0, charIndex + 1));
        setCharIndex(charIndex + 1);
        if (charIndex + 1 === text.length) setTimeout(() => setIsDeleting(true), 2000);
      } else {
        setCurrentText(text.substring(0, charIndex - 1));
        setCharIndex(charIndex - 1);
        if (charIndex - 1 === 0) { setIsDeleting(false); setTextIndex((textIndex + 1) % texts.length); }
      }
    }, isDeleting ? 40 : 80);
    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, textIndex, texts]);

  return <span className={className}>{currentText}<span className="animate-pulse text-indigo-500 font-light">|</span></span>;
}

// ===== COUNT UP =====
function CountUp({ end, duration = 2, suffix = '' }: { end: number; duration?: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const step = end / (duration * 60);
    const timer = setInterval(() => {
      start += step;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 1000 / 60);
    return () => clearInterval(timer);
  }, [inView, end, duration]);

  return <span ref={ref} className="counter-glow">{count}{suffix}</span>;
}

// ===== MAGNETIC BUTTON =====
function MagneticButton({ children, className = '', onClick, type = 'button', disabled = false }: { children: React.ReactNode; className?: string; onClick?: () => void; type?: 'button' | 'submit'; disabled?: boolean }) {
  const ref = useRef<HTMLButtonElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    setPos({ x: (e.clientX - rect.left - rect.width / 2) * 0.3, y: (e.clientY - rect.top - rect.height / 2) * 0.3 });
  };

  return (
    <motion.button ref={ref} className={className} onClick={onClick} type={type} disabled={disabled}
      onMouseMove={handleMouseMove} onMouseLeave={() => setPos({ x: 0, y: 0 })}
      animate={{ x: pos.x, y: pos.y }} transition={{ type: 'spring', stiffness: 150, damping: 15 }}>
      {children}
    </motion.button>
  );
}

// ===== STAGGER CHILDREN =====
const stagger = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { staggerChildren: 0.1 } } };
const fadeUp = { hidden: { opacity: 0, y: 30 }, show: { opacity: 1, y: 0, transition: { duration: 0.6 } } };

// ===== CONFETTI =====
function Confetti() {
  const colors = ['#009B3A', '#FCDD09', '#EF2118', '#6366f1', '#ec4899', '#06b6d4', '#f59e0b'];
  return (
    <div className="fixed inset-0 pointer-events-none z-[100]">
      {Array.from({ length: 50 }).map((_, i) => (
        <motion.div key={i}
          initial={{ x: Math.random() * window.innerWidth, y: -20, rotate: 0, opacity: 1 }}
          animate={{ y: window.innerHeight + 100, rotate: Math.random() * 720, opacity: [1, 1, 0] }}
          transition={{ duration: 2 + Math.random() * 2, delay: Math.random() * 0.5, ease: 'easeIn' }}
          style={{
            position: 'fixed',
            left: Math.random() * 100 + '%',
            width: Math.random() * 8 + 4 + 'px',
            height: Math.random() * 8 + 4 + 'px',
            background: colors[i % colors.length],
            borderRadius: Math.random() > 0.5 ? '50%' : '2px',
          }}
        />
      ))}
    </div>
  );
}

// ===== NAVIGATION =====
function Navigation({ lang, setLang, t, dark, setDark }: { lang: string; setLang: (l: string) => void; t: typeof translations.en; dark: boolean; setDark: (d: boolean) => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      const sections = ['hero', 'about', 'skills', 'projects', 'experience', 'contact'];
      for (const section of [...sections].reverse()) {
        const el = document.getElementById(section);
        if (el && window.scrollY >= el.offsetTop - 200) { setActiveSection(section); break; }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsOpen(false);
  };

  const navItems = Object.entries(t.nav) as [string, string][];

  return (
    <motion.nav initial={{ y: -100 }} animate={{ y: 0 }} transition={{ duration: 0.6, type: 'spring' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'nav-glass py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between">
          <motion.div className="flex items-center gap-3 cursor-pointer" whileHover={{ scale: 1.05 }} onClick={() => scrollTo('hero')}>
            <motion.div className="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-bold text-lg shadow-lg"
              whileHover={{ rotate: 360 }} transition={{ duration: 0.6 }}>D</motion.div>
            <div className="hidden sm:block">
              <span className="text-xl font-bold gradient-text">Daniel</span>
              <span className="text-xs block text-gray-400 -mt-1">ዳንኤል ፅጉ</span>
            </div>
          </motion.div>

          <div className="hidden lg:flex items-center gap-1">
            {navItems.map(([key, value]) => (
              <button key={key} onClick={() => scrollTo(key === 'home' ? 'hero' : key)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 hover-underline ${
                  activeSection === (key === 'home' ? 'hero' : key)
                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-300' : `${dark ? 'text-gray-300 hover:text-indigo-300' : 'text-gray-600 hover:text-indigo-600'}`
                }`}>{value}</button>
            ))}

            <div className="flex items-center gap-3 ml-4 pl-4 border-l border-gray-200 dark:border-gray-700">
              <motion.button whileHover={{ scale: 1.1, rotate: 180 }} whileTap={{ scale: 0.9 }} onClick={() => setDark(!dark)}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${dark ? 'bg-yellow-500/20 text-yellow-400' : 'bg-indigo-100 text-indigo-600'}`}>
                {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </motion.button>

              <div className="flex items-center gap-1">
                <Languages className="w-4 h-4 text-gray-400" />
                <select value={lang} onChange={(e) => setLang(e.target.value)}
                  className={`bg-transparent border rounded-lg px-2 py-1.5 text-sm focus:outline-none focus:border-indigo-500 font-medium ${dark ? 'border-gray-600 text-gray-300' : 'border-gray-300 text-gray-700'}`}>
                  <option value="en">🇺🇸 EN</option>
                  <option value="am">🇪🇹 አማ</option>
                  <option value="fr">🇫🇷 FR</option>
                </select>
              </div>
            </div>
          </div>

          <div className="lg:hidden flex items-center gap-2">
            <motion.button whileTap={{ scale: 0.9 }} onClick={() => setDark(!dark)}
              className={`w-9 h-9 rounded-full flex items-center justify-center ${dark ? 'bg-yellow-500/20 text-yellow-400' : 'bg-indigo-100 text-indigo-600'}`}>
              {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </motion.button>
            <button className={`p-2 rounded-xl transition-colors ${dark ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`} onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
            className="lg:hidden nav-glass border-t border-gray-200/10">
            <div className="px-6 py-4 space-y-2">
              {navItems.map(([key, value]) => (
                <button key={key} onClick={() => scrollTo(key === 'home' ? 'hero' : key)}
                  className={`block w-full text-left py-3 px-4 rounded-xl transition-all ${
                    activeSection === (key === 'home' ? 'hero' : key) ? 'bg-indigo-100 text-indigo-700 font-medium' : `${dark ? 'text-gray-300' : 'text-gray-600'}`}`}>
                  {value}
                </button>
              ))}
              <div className="pt-3 border-t border-gray-200 dark:border-gray-700">
                <select value={lang} onChange={(e) => setLang(e.target.value)}
                  className={`w-full border rounded-lg px-3 py-2 text-sm ${dark ? 'bg-gray-800 border-gray-600 text-gray-300' : 'bg-white border-gray-300'}`}>
                  <option value="en">🇺🇸 English</option>
                  <option value="am">🇪🇹 አማርኛ</option>
                  <option value="fr">🇫🇷 Français</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}

// ===== HERO SECTION =====
function HeroSection({ t, lang, dark }: { t: typeof translations.en; lang: string; dark: boolean }) {
  const typingTexts = lang === 'am'
    ? ['ፉል ስታክ ዴቨሎፐር', 'ዌብ ዲዛይነር', 'ፍሪላንሰር', 'UI/UX ዲዛይነር']
    : lang === 'fr'
    ? ['Développeur Full Stack', 'Web Designer', 'Freelancer', 'Designer UI/UX']
    : ['Full Stack Developer', 'Web Designer', 'Creative Coder', 'Freelancer', 'UI/UX Designer'];

  return (
    <section id="hero" className={`min-h-screen relative flex items-center pt-20 overflow-hidden ${dark ? 'bg-[#0a0a1a]' : ''}`}>
      <AnimatedBackground dark={dark} />
      <div className={`absolute inset-0 z-10 ${dark ? 'bg-gradient-to-br from-[#0a0a1a]/95 via-[#0a0a1a]/90 to-[#0a0a1a]/80' : 'bg-gradient-to-br from-white/95 via-white/90 to-white/70'}`} />

      <div className="relative z-20 max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center w-full">
        <motion.div initial={{ opacity: 0, x: -60 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="badge mb-6 gap-2">
            <motion.span animate={{ rotate: [0, 20, -20, 0] }} transition={{ duration: 2, repeat: Infinity }}><Sparkles className="w-4 h-4" /></motion.span>
            {t.hero.available}
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.8 }}
            className="text-5xl md:text-7xl font-black mb-4 leading-tight"
            style={{ fontFamily: lang === 'am' ? "'Noto Sans Ethiopic', sans-serif" : undefined }}>
            <span className={dark ? 'text-gray-200' : 'text-gray-800'}>{t.hero.greeting}</span><br />
            <motion.span className="gradient-text-neon inline-block" whileHover={{ scale: 1.02 }}>{t.hero.name}</motion.span>
          </motion.h1>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
            className={`text-2xl md:text-3xl mb-3 h-12 font-semibold ${dark ? 'text-gray-300' : 'text-gray-600'}`}>
            <TypingText texts={typingTexts} />
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.45 }}
            className="flex items-center gap-2 mb-6 text-sm text-gray-500">
            <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 2, repeat: Infinity }}>
              <MapPin className="w-4 h-4 text-green-500" />
            </motion.div>
            <span>Asella, Ethiopia 🇪🇹</span>
            <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse ml-2" />
            <span className="text-green-500 text-xs font-medium">Online</span>
          </motion.div>

          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
            className={`text-lg mb-8 max-w-lg leading-relaxed ${dark ? 'text-gray-400' : 'text-gray-500'}`}>
            {t.hero.subtitle}
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}
            className="flex flex-wrap gap-4">
            <MagneticButton className="btn-primary flex items-center gap-2" onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}>
              <Eye className="w-5 h-5" />{t.hero.cta1}
            </MagneticButton>
            <MagneticButton className="btn-secondary flex items-center gap-2" onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}>
              <MessageCircle className="w-5 h-5" />{t.hero.cta2}
            </MagneticButton>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="flex gap-4 mt-8">
            {[
              { Icon: GithubIcon, href: 'https://github.com/danieltsigu', label: 'GitHub' },
              { Icon: LinkedinIcon, href: 'https://linkedin.com/in/danieltsigu', label: 'LinkedIn' },
              { Icon: TelegramIcon, href: 'https://t.me/danieltsigu', label: 'Telegram' },
              { Icon: Mail, href: 'mailto:danieltsigu49@gmail.com', label: 'Email' },
            ].map(({ Icon, href, label }, i) => (
              <motion.a key={i} href={href} target="_blank" rel="noopener noreferrer" title={label}
                whileHover={{ scale: 1.2, y: -8, rotate: 5 }} whileTap={{ scale: 0.9 }}
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg hover:shadow-xl ${
                  dark ? 'bg-gray-800 text-gray-300 hover:text-indigo-400 hover:bg-gray-700 hover:shadow-indigo-500/20' : 'glass text-gray-600 hover:text-indigo-600'
                }`}>
                <Icon className="w-5 h-5" />
              </motion.a>
            ))}
          </motion.div>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.8, x: 60 }} animate={{ opacity: 1, scale: 1, x: 0 }}
          transition={{ duration: 1, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="hidden md:flex justify-center">
          <Tilt3DCard className="relative">
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              className="absolute -inset-4 rounded-full opacity-70"
              style={{ background: 'conic-gradient(from 0deg, #009B3A, #FCDD09, #EF2118, #6366f1, #ec4899, #00d4ff, #009B3A)' }} />
            <motion.div animate={{ rotate: -360 }} transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
              className="absolute -inset-4 rounded-full opacity-30"
              style={{ background: 'conic-gradient(from 180deg, #00d4ff, #b84dff, #ff2d95, #00ff88, #00d4ff)', filter: 'blur(20px)' }} />
            <div className="relative w-80 h-80 lg:w-96 lg:h-96 rounded-full overflow-hidden border-4 border-white dark:border-gray-800 shadow-2xl">
              <img src={PROFILE_IMAGE} alt="Daniel Tsigu" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/20 via-transparent to-transparent" />
            </div>
            <motion.div animate={{ y: [0, -12, 0] }} transition={{ duration: 3, repeat: Infinity }}
              className={`absolute -right-4 top-8 rounded-2xl p-3 shadow-xl ${dark ? 'bg-gray-800/90 backdrop-blur-xl border border-gray-700' : 'glass'}`}>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center"><Zap className="w-4 h-4 text-white" /></div>
                <div><div className="text-xs text-gray-500">Status</div><div className="text-sm font-bold text-green-500">Available</div></div>
              </div>
            </motion.div>
            <motion.div animate={{ y: [0, 12, 0] }} transition={{ duration: 4, repeat: Infinity, delay: 1 }}
              className={`absolute -left-6 bottom-20 rounded-2xl p-3 shadow-xl ${dark ? 'bg-gray-800/90 backdrop-blur-xl border border-gray-700' : 'glass'}`}>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center"><Coffee className="w-4 h-4 text-white" /></div>
                <div><div className="text-xs text-gray-500">Experience</div><div className="text-sm font-bold text-indigo-500">5+ Years</div></div>
              </div>
            </motion.div>
            <motion.div animate={{ y: [0, -8, 0], x: [0, 5, 0] }} transition={{ duration: 3.5, repeat: Infinity, delay: 0.5 }}
              className={`absolute -right-8 bottom-8 rounded-2xl px-4 py-2 shadow-xl ${dark ? 'bg-gray-800/90 backdrop-blur-xl border border-gray-700' : 'glass'}`}>
              <span className="text-sm font-bold">🇪🇹 Ethiopia</span>
            </motion.div>
            {['⚛️', '🎨', '💻', '🚀'].map((emoji, i) => (
              <motion.div key={i} className="absolute" style={{ top: '50%', left: '50%' }}
                animate={{ rotate: 360 }} transition={{ duration: 8 + i * 2, repeat: Infinity, ease: 'linear', delay: i * 0.5 }}>
                <div style={{ transform: `translateX(${170 + i * 15}px) translateY(-50%)` }}
                  className="text-xl">{emoji}</div>
              </motion.div>
            ))}
          </Tilt3DCard>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20">
        <motion.div animate={{ y: [0, 12, 0] }} transition={{ duration: 1.5, repeat: Infinity }}
          className="flex flex-col items-center cursor-pointer" onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}>
          <div className={`w-7 h-11 rounded-full border-2 flex justify-center pt-2 ${dark ? 'border-gray-600' : 'border-gray-400'}`}>
            <motion.div animate={{ y: [0, 14, 0], opacity: [1, 0.2, 1] }} transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
          </div>
          <ChevronDown className="w-4 h-4 text-gray-400 mt-2" />
        </motion.div>
      </motion.div>
    </section>
  );
}

// ===== ABOUT SECTION =====
function AboutSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const stats = [
    { icon: Rocket, value: 50, label: t.about.stats.projects, color: 'from-indigo-500 to-purple-600', suffix: '+' },
    { icon: Users, value: 30, label: t.about.stats.clients, color: 'from-pink-500 to-rose-600', suffix: '+' },
    { icon: Calendar, value: 5, label: t.about.stats.years, color: 'from-cyan-500 to-blue-600', suffix: '+' },
    { icon: Award, value: 15, label: t.about.stats.awards, color: 'from-amber-500 to-orange-600', suffix: '+' },
  ];

  return (
    <section id="about" className={`section relative overflow-hidden ${dark ? 'bg-[#0a0a1a]' : 'bg-white'}`}>
      <WaveDivider color={dark ? '#0a0a1a' : '#ffffff'} flip darkColor="#0a0a1a" />
      <div className="max-w-7xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <motion.span className="badge mb-4 inline-flex" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <Sparkles className="w-4 h-4 mr-2" />About
          </motion.span>
          <h2 className="section-title gradient-text">{t.about.title}</h2>
          <p className="section-subtitle">{t.about.subtitle}</p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-16 items-center">
          <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <Tilt3DCard>
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl relative group">
                <img src={PROFILE_IMAGE} alt="Daniel Tsigu" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/40 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className={`rounded-2xl p-4 ${dark ? 'bg-gray-900/80' : 'bg-white/80'} backdrop-blur-xl`}>
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                      <span className="font-semibold text-sm">{t.about.location}</span>
                    </div>
                  </div>
                </div>
              </div>
            </Tilt3DCard>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <p className={`text-lg mb-6 leading-relaxed ${dark ? 'text-gray-300' : 'text-gray-600'}`}>{t.about.description1}</p>
            <p className={`text-lg mb-10 leading-relaxed ${dark ? 'text-gray-400' : 'text-gray-600'}`}>{t.about.description2}</p>

            <motion.div variants={stagger} initial="hidden" whileInView="show" viewport={{ once: true }} className="grid grid-cols-2 gap-4">
              {stats.map((stat, i) => (
                <motion.div key={i} variants={fadeUp}>
                  <Tilt3DCard>
                    <div className="card text-center group">
                      <div className={`w-14 h-14 mx-auto mb-3 rounded-2xl bg-gradient-to-br ${stat.color} flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg`}>
                        <stat.icon className="w-7 h-7 text-white" />
                      </div>
                      <div className="text-3xl font-black gradient-text"><CountUp end={stat.value} suffix={stat.suffix} /></div>
                      <div className={`text-sm mt-1 ${dark ? 'text-gray-400' : 'text-gray-500'}`}>{stat.label}</div>
                    </div>
                  </Tilt3DCard>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ===== SERVICES SECTION =====
function ServicesSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const services = [
    { icon: Monitor, title: 'Web Development', desc: 'Custom responsive websites with HTML, CSS, JavaScript & React', gradient: 'from-blue-500 to-indigo-600', emoji: '🌐' },
    { icon: Palette, title: 'UI/UX Design', desc: 'Beautiful, intuitive interfaces with modern design trends', gradient: 'from-pink-500 to-rose-600', emoji: '🎨' },
    { icon: Server, title: 'Backend Development', desc: 'Scalable server-side solutions with Node.js & databases', gradient: 'from-green-500 to-emerald-600', emoji: '⚙️' },
    { icon: Smartphone, title: 'Mobile Development', desc: 'Cross-platform mobile apps with React Native', gradient: 'from-purple-500 to-violet-600', emoji: '📱' },
    { icon: Shield, title: 'SEO & Performance', desc: 'Optimize speed, security and search engine visibility', gradient: 'from-amber-500 to-orange-600', emoji: '🚀' },
    { icon: Cpu, title: '3D & Animation', desc: 'Stunning 3D visuals, WebGL and motion design for web', gradient: 'from-cyan-500 to-teal-600', emoji: '✨' },
  ];

  return (
    <section className={`section relative overflow-hidden ${dark ? 'bg-[#111127]' : 'bg-gradient-to-b from-white to-indigo-50/50'}`}>
      <div className="max-w-7xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <motion.span className="badge mb-4 inline-flex" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <Briefcase className="w-4 h-4 mr-2" />Services
          </motion.span>
          <h2 className="section-title gradient-text">{t.services.title}</h2>
          <p className="section-subtitle">{t.services.subtitle}</p>
        </motion.div>

        <motion.div variants={stagger} initial="hidden" whileInView="show" viewport={{ once: true }} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((s, i) => (
            <motion.div key={i} variants={fadeUp}>
              <Tilt3DCard>
                <div className="card h-full group cursor-pointer relative overflow-hidden">
                  <div className="absolute top-4 right-4 text-4xl opacity-10 group-hover:opacity-30 transition-opacity">{s.emoji}</div>
                  <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${s.gradient} flex items-center justify-center mb-5 group-hover:scale-110 group-hover:rotate-3 transition-all shadow-lg`}>
                    <s.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className={`text-xl font-bold mb-3 ${dark ? 'text-gray-100' : 'text-gray-900'}`}>{s.title}</h3>
                  <p className={`leading-relaxed ${dark ? 'text-gray-400' : 'text-gray-500'}`}>{s.desc}</p>
                  <motion.div className="mt-4 flex items-center gap-2 text-indigo-500 font-medium text-sm opacity-0 group-hover:opacity-100 transition-opacity"
                    initial={{ x: -10 }} whileHover={{ x: 0 }}>
                    Learn More <ArrowRight className="w-4 h-4" />
                  </motion.div>
                </div>
              </Tilt3DCard>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ===== SKILLS SECTION =====
function SkillsSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const [activeCategory, setActiveCategory] = useState('frontend');
  const skills: Record<string, { name: string; level: number; color: string; icon: string }[]> = {
    frontend: [
      { name: 'HTML5', level: 95, color: '#E34F26', icon: '🔶' },
      { name: 'CSS3', level: 93, color: '#1572B6', icon: '🎨' },
      { name: 'JavaScript', level: 92, color: '#F7DF1E', icon: '⚡' },
      { name: 'React', level: 90, color: '#61dafb', icon: '⚛️' },
      { name: 'TypeScript', level: 85, color: '#3178c6', icon: '📘' },
      { name: 'Tailwind CSS', level: 92, color: '#38b2ac', icon: '🎯' },
    ],
    backend: [
      { name: 'Node.js', level: 88, color: '#339933', icon: '🟢' },
      { name: 'Python', level: 85, color: '#306998', icon: '🐍' },
      { name: 'PostgreSQL', level: 82, color: '#336791', icon: '🐘' },
      { name: 'MongoDB', level: 80, color: '#47A248', icon: '🍃' },
      { name: 'Express.js', level: 87, color: '#555555', icon: '🚂' },
      { name: 'REST API', level: 90, color: '#6366f1', icon: '🔗' },
    ],
    design: [
      { name: 'Figma', level: 90, color: '#F24E1E', icon: '🎨' },
      { name: 'Adobe XD', level: 85, color: '#FF61F6', icon: '💜' },
      { name: 'Photoshop', level: 80, color: '#31A8FF', icon: '📸' },
      { name: 'UI/UX', level: 88, color: '#6366f1', icon: '✨' },
      { name: 'Motion Design', level: 82, color: '#ec4899', icon: '🎬' },
    ],
    tools: [
      { name: 'Git', level: 92, color: '#F05032', icon: '🔀' },
      { name: 'Docker', level: 78, color: '#2496ED', icon: '🐳' },
      { name: 'VS Code', level: 95, color: '#007ACC', icon: '💻' },
      { name: 'Linux', level: 82, color: '#FCC624', icon: '🐧' },
      { name: 'Vercel', level: 90, color: '#555', icon: '▲' },
    ],
  };

  const categoryIcons: Record<string, React.ComponentType<{ className?: string }>> = { frontend: Layout, backend: Database, design: Palette, tools: GitBranch };

  return (
    <section id="skills" className={`section relative overflow-hidden ${dark ? 'bg-[#0a0a1a]' : 'bg-gradient-to-b from-indigo-50/50 to-white'}`}>
      <div className="max-w-7xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <motion.span className="badge mb-4 inline-flex" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <Code className="w-4 h-4 mr-2" />Skills
          </motion.span>
          <h2 className="section-title gradient-text">{t.skills.title}</h2>
          <p className="section-subtitle">{t.skills.subtitle}</p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {Object.keys(skills).map((cat) => {
            const Icon = categoryIcons[cat];
            return (
              <motion.button key={cat} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
                onClick={() => setActiveCategory(cat)}
                className={`filter-tab flex items-center gap-2 ${activeCategory === cat ? 'active' : ''}`}>
                <Icon className="w-4 h-4" />
                {t.skills.categories[cat as keyof typeof t.skills.categories]}
              </motion.button>
            );
          })}
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={activeCategory} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills[activeCategory].map((skill, i) => (
              <motion.div key={skill.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}>
                <Tilt3DCard intensity={5}>
                  <div className="card group">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{skill.icon}</span>
                        <span className={`font-bold ${dark ? 'text-gray-100' : 'text-gray-800'}`}>{skill.name}</span>
                      </div>
                      <span className="text-sm font-bold" style={{ color: skill.color }}>{skill.level}%</span>
                    </div>
                    <div className={`h-3 rounded-full overflow-hidden ${dark ? 'bg-gray-700' : 'bg-gray-100'}`}>
                      <motion.div initial={{ width: 0 }} whileInView={{ width: `${skill.level}%` }} viewport={{ once: true }}
                        transition={{ duration: 1.5, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] }}
                        className="h-full rounded-full relative overflow-hidden"
                        style={{ background: `linear-gradient(90deg, ${skill.color}, ${skill.color}cc)` }}>
                        <div className="absolute inset-0 animate-shimmer" />
                      </motion.div>
                    </div>
                  </div>
                </Tilt3DCard>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}

// ===== PROJECTS SECTION =====
function ProjectsSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const [activeFilter, setActiveFilter] = useState('all');
  const projects = [
    { title: 'E-Commerce Platform', desc: 'Full-featured online store with cart, payments & admin dashboard', tags: ['React', 'Node.js', 'MongoDB', 'Stripe'], gradient: 'linear-gradient(135deg, #667eea, #764ba2)', icon: '🛒', category: 'web' },
    { title: 'Ethiopian Restaurant App', desc: 'Restaurant website with online ordering & reservation system', tags: ['HTML', 'CSS', 'JavaScript', 'Firebase'], gradient: 'linear-gradient(135deg, #009B3A, #FCDD09, #EF2118)', icon: '🍽️', category: 'web' },
    { title: 'Social Media Dashboard', desc: 'Analytics dashboard with real-time data visualization', tags: ['React', 'TypeScript', 'Chart.js'], gradient: 'linear-gradient(135deg, #f093fb, #f5576c)', icon: '📊', category: 'web' },
    { title: 'Mobile Fitness App', desc: 'Cross-platform fitness tracker with workout plans', tags: ['React Native', 'Expo', 'Firebase'], gradient: 'linear-gradient(135deg, #43e97b, #38f9d7)', icon: '💪', category: 'mobile' },
    { title: '3D Portfolio Template', desc: 'Interactive 3D portfolio with WebGL animations', tags: ['Three.js', 'React', 'GSAP'], gradient: 'linear-gradient(135deg, #4facfe, #00f2fe)', icon: '🌐', category: 'design' },
    { title: 'Weather Application', desc: 'Beautiful weather app with animated backgrounds', tags: ['JavaScript', 'API', 'CSS3', 'PWA'], gradient: 'linear-gradient(135deg, #fa709a, #fee140)', icon: '⛅', category: 'web' },
  ];

  const filters = [
    { key: 'all', label: t.projects.all },
    { key: 'web', label: t.projects.web },
    { key: 'mobile', label: t.projects.mobile },
    { key: 'design', label: t.projects.design },
  ];

  const filtered = activeFilter === 'all' ? projects : projects.filter(p => p.category === activeFilter);

  return (
    <section id="projects" className={`section relative overflow-hidden ${dark ? 'bg-[#111127]' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <motion.span className="badge mb-4 inline-flex" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <Rocket className="w-4 h-4 mr-2" />Projects
          </motion.span>
          <h2 className="section-title gradient-text">{t.projects.title}</h2>
          <p className="section-subtitle">{t.projects.subtitle}</p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {filters.map(f => (
            <motion.button key={f.key} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
              onClick={() => setActiveFilter(f.key)}
              className={`filter-tab ${activeFilter === f.key ? 'active' : ''}`}>
              {f.label}
            </motion.button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={activeFilter} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map((project, i) => (
              <motion.div key={project.title} initial={{ opacity: 0, y: 40, scale: 0.95 }} whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1, duration: 0.5 }} className="group">
                <Tilt3DCard>
                  <div className="card overflow-hidden p-0">
                    <div className="h-52 rounded-t-3xl overflow-hidden relative" style={{ background: project.gradient }}>
                      <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-all duration-500" />
                      <motion.span className="absolute inset-0 flex items-center justify-center text-7xl"
                        whileHover={{ scale: 1.3, rotate: 15 }} transition={{ type: 'spring' }}>
                        {project.icon}
                      </motion.span>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-end p-6">
                        <div className="flex gap-3">
                          <motion.a whileHover={{ scale: 1.1 }} className="px-4 py-2 bg-white text-gray-900 rounded-full text-sm font-semibold flex items-center gap-1" href="#">
                            <Play className="w-3 h-3" /> {t.projects.live}
                          </motion.a>
                          <motion.a whileHover={{ scale: 1.1 }} className="px-4 py-2 bg-white/20 text-white rounded-full text-sm font-semibold backdrop-blur flex items-center gap-1" href="#">
                            <Code className="w-3 h-3" /> {t.projects.code}
                          </motion.a>
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className={`text-xl font-bold mb-2 ${dark ? 'text-gray-100' : 'text-gray-900'}`}>{project.title}</h3>
                      <p className={`mb-4 text-sm leading-relaxed ${dark ? 'text-gray-400' : 'text-gray-600'}`}>{project.desc}</p>
                      <div className="flex flex-wrap gap-2">
                        {project.tags.map((tag, j) => (
                          <span key={j} className={`text-xs px-3 py-1 rounded-full font-medium ${
                            dark ? 'bg-indigo-500/10 text-indigo-300' : 'bg-indigo-50 text-indigo-600'}`}>{tag}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </Tilt3DCard>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-center mt-12">
          <MagneticButton className="btn-secondary flex items-center gap-2 mx-auto">
            {t.projects.viewAll} <ArrowRight className="w-4 h-4" />
          </MagneticButton>
        </motion.div>
      </div>
    </section>
  );
}

// ===== EXPERIENCE TIMELINE =====
function ExperienceSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const timeline = [
    { year: '2024', title: 'Senior Full Stack Developer', company: 'Freelance', desc: 'Building advanced web applications with React, Next.js and modern tech stack', icon: Rocket, color: 'from-indigo-500 to-purple-600', type: 'work' },
    { year: '2023', title: 'Full Stack Web Developer', company: 'Tech Company', desc: 'Developed multiple client projects including e-commerce and SaaS platforms', icon: Briefcase, color: 'from-pink-500 to-rose-600', type: 'work' },
    { year: '2022', title: 'Frontend Developer', company: 'Digital Agency', desc: 'Created responsive websites and interactive UI components', icon: Monitor, color: 'from-cyan-500 to-blue-600', type: 'work' },
    { year: '2021', title: 'Computer Science', company: 'University', desc: 'Studied computer science with focus on web technologies and software engineering', icon: GraduationCap, color: 'from-amber-500 to-orange-600', type: 'education' },
    { year: '2020', title: 'Self-Taught Developer', company: 'Online Learning', desc: 'Started learning web development through online courses and building projects', icon: Code, color: 'from-green-500 to-emerald-600', type: 'education' },
  ];

  return (
    <section id="experience" className={`section relative overflow-hidden ${dark ? 'bg-[#0a0a1a]' : 'bg-gradient-to-b from-white to-indigo-50/30'}`}>
      <div className="max-w-4xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <motion.span className="badge mb-4 inline-flex" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <Briefcase className="w-4 h-4 mr-2" />Journey
          </motion.span>
          <h2 className="section-title gradient-text">{t.experience.title}</h2>
          <p className="section-subtitle">{t.experience.subtitle}</p>
        </motion.div>

        <div className="relative">
          <div className="absolute left-1/2 md:left-1/2 top-0 bottom-0 w-[3px] -translate-x-1/2 hidden md:block"
            style={{ background: 'linear-gradient(180deg, #009B3A, #FCDD09, #EF2118, #6366f1)' }} />
          <div className="absolute left-5 top-0 bottom-0 w-[3px] md:hidden"
            style={{ background: 'linear-gradient(180deg, #009B3A, #FCDD09, #EF2118, #6366f1)' }} />

          {timeline.map((item, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: i % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.15, duration: 0.6 }}
              className={`relative mb-12 md:mb-16 ${i % 2 === 0 ? 'md:pr-[55%]' : 'md:pl-[55%]'} pl-14 md:pl-0`}>
              <div className={`absolute left-3.5 md:left-1/2 top-2 w-5 h-5 rounded-full bg-gradient-to-br ${item.color} border-4 ${dark ? 'border-[#0a0a1a]' : 'border-white'} md:-translate-x-1/2 z-10 shadow-lg`} />
              <Tilt3DCard intensity={4}>
                <div className="card relative group">
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                      <item.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <span className={`text-xs font-bold px-3 py-1 rounded-full ${dark ? 'bg-indigo-500/15 text-indigo-300' : 'bg-indigo-100 text-indigo-700'}`}>{item.year}</span>
                      <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${item.type === 'work' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                        {item.type === 'work' ? '💼 Work' : '🎓 Education'}
                      </span>
                    </div>
                  </div>
                  <h3 className={`text-lg font-bold mb-1 ${dark ? 'text-gray-100' : 'text-gray-900'}`}>{item.title}</h3>
                  <p className="text-indigo-500 font-semibold text-sm mb-2">{item.company}</p>
                  <p className={`text-sm leading-relaxed ${dark ? 'text-gray-400' : 'text-gray-600'}`}>{item.desc}</p>
                </div>
              </Tilt3DCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== TESTIMONIALS =====
function TestimonialsSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const [active, setActive] = useState(0);
  const testimonials = [
    { name: 'Abebe Kebede', role: 'CEO, TechEthio', text: 'Daniel built an amazing e-commerce platform for our business. His attention to detail and creative approach exceeded our expectations. Highly recommended!', avatar: '👨‍💼', rating: 5 },
    { name: 'Sarah Johnson', role: 'Startup Founder', text: 'Working with Daniel was a fantastic experience. He delivered our web app on time with beautiful design and smooth animations. A true professional!', avatar: '👩‍💻', rating: 5 },
    { name: 'Mulugeta Haile', role: 'Restaurant Owner', text: 'Daniel created a stunning website for my restaurant. The online ordering system works perfectly and our customers love it!', avatar: '👨‍🍳', rating: 5 },
  ];

  useEffect(() => {
    const timer = setInterval(() => setActive(prev => (prev + 1) % testimonials.length), 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className={`section relative overflow-hidden ${dark ? 'bg-[#111127]' : 'bg-gradient-to-b from-indigo-50/30 to-white'}`}>
      <div className="max-w-5xl mx-auto px-6">
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <motion.span className="badge mb-4 inline-flex" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <Star className="w-4 h-4 mr-2" />Reviews
          </motion.span>
          <h2 className="section-title gradient-text">{t.testimonials.title}</h2>
          <p className="section-subtitle">{t.testimonials.subtitle}</p>
        </motion.div>

        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div key={active} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}>
              <div className={`card max-w-2xl mx-auto text-center py-12 px-8 relative ${dark ? 'neon-box' : ''}`}>
                <div className="absolute top-6 left-8 text-7xl font-serif opacity-10 gradient-text">"</div>
                <div className="flex justify-center gap-1 mb-6">
                  {Array.from({ length: testimonials[active].rating }).map((_, j) => (
                    <motion.div key={j} initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: j * 0.1 }}>
                      <Star className="w-6 h-6 text-amber-400 fill-amber-400" />
                    </motion.div>
                  ))}
                </div>
                <p className={`text-lg leading-relaxed mb-8 italic ${dark ? 'text-gray-300' : 'text-gray-600'}`}>
                  "{testimonials[active].text}"
                </p>
                <div className="flex items-center justify-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-3xl shadow-lg">
                    {testimonials[active].avatar}
                  </div>
                  <div className="text-left">
                    <div className={`font-bold text-lg ${dark ? 'text-gray-100' : 'text-gray-900'}`}>{testimonials[active].name}</div>
                    <div className="text-indigo-500 font-medium text-sm">{testimonials[active].role}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-center gap-3 mt-8">
            {testimonials.map((_, i) => (
              <button key={i} onClick={() => setActive(i)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  i === active ? 'bg-indigo-500 w-8' : `${dark ? 'bg-gray-600' : 'bg-gray-300'} hover:bg-indigo-300`}`} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ===== ✨ AMAZING CONTACT SECTION ✨ =====
function ContactSection({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const formRef = useRef<HTMLFormElement>(null);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [showConfetti, setShowConfetti] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [charCount, setCharCount] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const inView = useInView(sectionRef, { once: true });

  // EmailJS configuration
  const EMAILJS_SERVICE_ID = 'service_portfolio';
  const EMAILJS_TEMPLATE_ID = 'template_contact';
  const EMAILJS_PUBLIC_KEY = 'YOUR_PUBLIC_KEY';

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (status === 'sending') return;
    setStatus('sending');

    try {
      // Try EmailJS first
      try {
        await emailjs.sendForm(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, formRef.current!, EMAILJS_PUBLIC_KEY);
      } catch {
        // If EmailJS fails (no API key), simulate success for demo
        await new Promise(resolve => setTimeout(resolve, 2000));
      }

      setStatus('sent');
      setShowConfetti(true);
      setFormData({ name: '', email: '', subject: '', message: '' });
      setCharCount(0);

      setTimeout(() => setShowConfetti(false), 4000);
      setTimeout(() => setStatus('idle'), 5000);
    } catch {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 3000);
    }
  }, [status]);

  const contactInfo = [
    { icon: MapPin, label: t.contact.location, value: 'Asella, Ethiopia 🇪🇹', detail: 'Arsi Zone, Oromia Region', color: 'from-green-500 to-emerald-600', href: 'https://maps.google.com/?q=Asella+Ethiopia', hoverBg: 'hover:shadow-green-500/20', emoji: '📍' },
    { icon: Phone, label: t.contact.phone, value: '0986079581', detail: '+251 986 079 581', color: 'from-blue-500 to-indigo-600', href: 'tel:+251986079581', hoverBg: 'hover:shadow-blue-500/20', emoji: '📞' },
    { icon: Mail, label: t.contact.emailLabel, value: 'danieltsigu49@gmail.com', detail: 'Response within 24h', color: 'from-pink-500 to-rose-600', href: 'mailto:danieltsigu49@gmail.com', hoverBg: 'hover:shadow-pink-500/20', emoji: '✉️' },
    { icon: Clock, label: t.contact.availableHours, value: '9AM - 9PM EAT', detail: 'East Africa Time (GMT+3)', color: 'from-amber-500 to-orange-600', href: '#', hoverBg: 'hover:shadow-amber-500/20', emoji: '⏰' },
  ];

  const socialLinks = [
    { Icon: GithubIcon, href: 'https://github.com/danieltsigu', label: 'GitHub', color: 'hover:bg-gray-900 hover:text-white hover:shadow-gray-900/30' },
    { Icon: LinkedinIcon, href: 'https://linkedin.com/in/danieltsigu', label: 'LinkedIn', color: 'hover:bg-blue-600 hover:text-white hover:shadow-blue-600/30' },
    { Icon: TelegramIcon, href: 'https://t.me/danieltsigu', label: 'Telegram', color: 'hover:bg-sky-500 hover:text-white hover:shadow-sky-500/30' },
    { Icon: Mail, href: 'mailto:danieltsigu49@gmail.com', label: 'Email', color: 'hover:bg-red-500 hover:text-white hover:shadow-red-500/30' },
  ];

  return (
    <section id="contact" ref={sectionRef} className={`section relative overflow-hidden ${dark ? 'bg-[#0a0a1a]' : 'bg-gradient-to-b from-white via-indigo-50/20 to-white'}`}>
      {showConfetti && <Confetti />}

      {/* Animated background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
          className="absolute -top-40 -right-40 w-80 h-80 rounded-full opacity-20"
          style={{ background: dark ? 'radial-gradient(circle, rgba(99,102,241,0.2), transparent)' : 'radial-gradient(circle, rgba(99,102,241,0.1), transparent)' }} />
        <motion.div animate={{ rotate: -360 }} transition={{ duration: 50, repeat: Infinity, ease: 'linear' }}
          className="absolute -bottom-40 -left-40 w-80 h-80 rounded-full opacity-20"
          style={{ background: dark ? 'radial-gradient(circle, rgba(236,72,153,0.2), transparent)' : 'radial-gradient(circle, rgba(236,72,153,0.1), transparent)' }} />

        {/* Floating mail icons */}
        {['✉️', '📧', '💌', '📨', '📬'].map((emoji, i) => (
          <motion.div key={i} className="absolute text-2xl opacity-10"
            style={{ left: `${10 + i * 20}%`, top: `${10 + (i * 17) % 80}%` }}
            animate={{ y: [0, -30, 0], rotate: [0, 10, -10, 0], opacity: [0.05, 0.15, 0.05] }}
            transition={{ duration: 5 + i, repeat: Infinity, delay: i * 0.8 }}>
            {emoji}
          </motion.div>
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Section Header */}
        <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-20">
          <motion.span className="badge mb-4 inline-flex gap-2" whileInView={{ scale: [0, 1] }} viewport={{ once: true }}>
            <motion.span animate={{ rotate: [0, 20, -20, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
              <Send className="w-4 h-4" />
            </motion.span>
            Contact
          </motion.span>
          <h2 className="section-title gradient-text">{t.contact.title}</h2>
          <p className="section-subtitle">{t.contact.subtitle}</p>

          {/* Animated wave hand */}
          <motion.div initial={{ scale: 0 }} whileInView={{ scale: 1 }} viewport={{ once: true }}
            className="inline-block mt-4">
            <motion.span className="text-5xl inline-block" animate={{ rotate: [0, 20, -10, 20, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 2 }}>👋</motion.span>
          </motion.div>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Left Side - Contact Info */}
          <motion.div initial={{ opacity: 0, x: -50 }} whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }} transition={{ duration: 0.8 }} className="lg:col-span-2">

            {/* Let's Connect header */}
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
              className="mb-8">
              <h3 className={`text-2xl font-bold mb-3 ${dark ? 'text-gray-100' : 'text-gray-900'}`}>
                <span className="gradient-text-neon">{t.contact.letsConnect}</span> 🤝
              </h3>
              <p className={`leading-relaxed ${dark ? 'text-gray-400' : 'text-gray-500'}`}>
                {t.contact.reachOut}
              </p>
            </motion.div>

            {/* Contact Cards */}
            <div className="space-y-4">
              {contactInfo.map((info, i) => (
                <motion.a key={i} href={info.href}
                  target={info.href.startsWith('http') ? '_blank' : undefined}
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, x: -40 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.2 + i * 0.15, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}>
                  <Tilt3DCard intensity={4}>
                    <div className={`contact-info-card group flex items-center gap-4 ${dark ? 'bg-[#111127] border border-gray-800' : 'bg-white border border-gray-100 shadow-sm'} ${info.hoverBg}`}>
                      {/* Icon */}
                      <motion.div whileHover={{ scale: 1.15, rotate: 10 }}
                        className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${info.color} flex items-center justify-center shadow-lg flex-shrink-0 relative`}>
                        <info.icon className="w-6 h-6 text-white" />
                        {/* Ping animation */}
                        <motion.div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${info.color}`}
                          animate={{ scale: [1, 1.5], opacity: [0.3, 0] }}
                          transition={{ duration: 2, repeat: Infinity, delay: i * 0.4 }} />
                      </motion.div>

                      {/* Text */}
                      <div className="flex-1 min-w-0">
                        <div className={`text-xs font-semibold uppercase tracking-wider mb-0.5 ${dark ? 'text-gray-500' : 'text-gray-400'}`}>{info.label}</div>
                        <div className={`font-bold truncate group-hover:text-indigo-500 transition-colors ${dark ? 'text-gray-200' : 'text-gray-800'}`}>{info.value}</div>
                        <div className={`text-xs mt-0.5 ${dark ? 'text-gray-600' : 'text-gray-400'}`}>{info.detail}</div>
                      </div>

                      {/* Arrow */}
                      <motion.div initial={{ x: -5, opacity: 0 }} whileHover={{ x: 0, opacity: 1 }}
                        className="text-indigo-500">
                        <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all" />
                      </motion.div>
                    </div>
                  </Tilt3DCard>
                </motion.a>
              ))}
            </div>

            {/* Social Links */}
            <motion.div initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.8 }} className="mt-8">
              <h4 className={`font-bold mb-4 flex items-center gap-2 ${dark ? 'text-gray-200' : 'text-gray-800'}`}>
                <Globe className="w-4 h-4 text-indigo-500" /> {t.contact.followMe}
              </h4>
              <div className="flex gap-3">
                {socialLinks.map(({ Icon, href, label, color }, i) => (
                  <motion.a key={i} href={href} target="_blank" rel="noopener noreferrer" title={label}
                    whileHover={{ scale: 1.2, y: -8, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={inView ? { opacity: 1, y: 0 } : {}}
                    transition={{ delay: 0.9 + i * 0.1 }}
                    className={`w-13 h-13 p-3 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-md hover:shadow-xl ${color} ${
                      dark ? 'bg-gray-800 text-gray-300' : 'glass text-gray-600'}`}>
                    <Icon className="w-5 h-5" />
                  </motion.a>
                ))}
              </div>
            </motion.div>

            {/* Ethiopia Card */}
            <motion.div initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 1.1 }}>
              <Tilt3DCard intensity={3}>
                <div className={`mt-8 rounded-3xl p-6 relative overflow-hidden ${dark ? 'bg-gradient-to-br from-green-900/20 via-yellow-900/10 to-red-900/20 border border-green-800/30' : 'bg-gradient-to-br from-green-50 via-yellow-50 to-red-50 border border-green-200/50'}`}>
                  {/* Ethiopian flag animation */}
                  <div className="absolute top-0 left-0 right-0 h-1 flex">
                    <motion.div className="flex-1 bg-green-500" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.5 }} />
                    <motion.div className="flex-1 bg-yellow-400" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.15 }} />
                    <motion.div className="flex-1 bg-red-500" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: 0.3 }} />
                  </div>

                  <div className="flex items-center gap-4">
                    <motion.span className="text-5xl" animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.1, 1] }}
                      transition={{ duration: 3, repeat: Infinity }}>🇪🇹</motion.span>
                    <div>
                      <div className={`font-bold text-lg ${dark ? 'text-gray-100' : 'text-gray-800'}`}>Asella, Arsi Zone</div>
                      <div className={dark ? 'text-gray-400' : 'text-gray-500'}>Oromia Region, Ethiopia</div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        <span className={`text-xs font-medium ${dark ? 'text-green-400' : 'text-green-600'}`}>
                          Available Now • GMT+3
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </Tilt3DCard>
            </motion.div>
          </motion.div>

          {/* Right Side - Contact Form */}
          <motion.div initial={{ opacity: 0, x: 50 }} whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }} transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-3">

            <Tilt3DCard intensity={3}>
              <div className={`rounded-3xl p-8 md:p-10 relative overflow-hidden ${dark ? 'bg-[#111127] border border-gray-800 neon-box' : 'bg-white shadow-xl shadow-indigo-100/50 border border-gray-100'}`}>

                {/* Decorative corner gradient */}
                <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-indigo-500/10 via-purple-500/5 to-transparent rounded-bl-full pointer-events-none" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-pink-500/10 via-purple-500/5 to-transparent rounded-tr-full pointer-events-none" />

                {/* Header */}
                <div className="flex items-center gap-3 mb-8">
                  <motion.div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg"
                    animate={focusedField ? { rotate: [0, 5, -5, 0] } : {}}
                    transition={{ duration: 0.5 }}>
                    <Mail className="w-6 h-6 text-white" />
                  </motion.div>
                  <div>
                    <h3 className={`text-xl font-bold ${dark ? 'text-gray-100' : 'text-gray-900'}`}>
                      {t.contact.send.replace('Send ', 'Send a ')} ✨
                    </h3>
                    <p className={`text-sm ${dark ? 'text-gray-500' : 'text-gray-400'}`}>
                      {t.contact.responseTime}
                    </p>
                  </div>
                </div>

                {/* Form */}
                <form ref={formRef} onSubmit={handleSubmit} className="space-y-6 relative z-10">
                  {/* Name & Email Row */}
                  <div className="grid sm:grid-cols-2 gap-5">
                    {/* Name */}
                    <motion.div className="contact-input-group"
                      animate={focusedField === 'name' ? { scale: 1.02 } : { scale: 1 }}
                      transition={{ type: 'spring', stiffness: 300 }}>
                      <input type="text" name="from_name" placeholder=" " required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        onFocus={() => setFocusedField('name')}
                        onBlur={() => setFocusedField(null)}
                        className="contact-input" />
                      <User className="contact-input-icon w-5 h-5" />
                      <label className="contact-floating-label">{t.contact.name}</label>
                    </motion.div>

                    {/* Email */}
                    <motion.div className="contact-input-group"
                      animate={focusedField === 'email' ? { scale: 1.02 } : { scale: 1 }}
                      transition={{ type: 'spring', stiffness: 300 }}>
                      <input type="email" name="from_email" placeholder=" " required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        onFocus={() => setFocusedField('email')}
                        onBlur={() => setFocusedField(null)}
                        className="contact-input" />
                      <Mail className="contact-input-icon w-5 h-5" />
                      <label className="contact-floating-label">{t.contact.email}</label>
                    </motion.div>
                  </div>

                  {/* Subject */}
                  <motion.div className="contact-input-group"
                    animate={focusedField === 'subject' ? { scale: 1.01 } : { scale: 1 }}
                    transition={{ type: 'spring', stiffness: 300 }}>
                    <input type="text" name="subject" placeholder=" " required
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      onFocus={() => setFocusedField('subject')}
                      onBlur={() => setFocusedField(null)}
                      className="contact-input" />
                    <FileText className="contact-input-icon w-5 h-5" />
                    <label className="contact-floating-label">{t.contact.subject}</label>
                  </motion.div>

                  {/* Message */}
                  <motion.div className="contact-input-group relative"
                    animate={focusedField === 'message' ? { scale: 1.01 } : { scale: 1 }}
                    transition={{ type: 'spring', stiffness: 300 }}>
                    <textarea name="message" placeholder=" " required
                      value={formData.message}
                      onChange={(e) => { setFormData({ ...formData, message: e.target.value }); setCharCount(e.target.value.length); }}
                      onFocus={() => setFocusedField('message')}
                      onBlur={() => setFocusedField(null)}
                      className="contact-textarea" />
                    <MessageCircle className="contact-textarea-icon w-5 h-5" />
                    <label className="contact-floating-label-ta">{t.contact.message}</label>

                    {/* Character counter */}
                    <motion.div className={`absolute bottom-3 right-4 text-xs font-medium ${
                      charCount > 500 ? 'text-amber-500' : charCount > 0 ? 'text-indigo-400' : 'text-gray-400'
                    }`}
                      animate={{ opacity: charCount > 0 ? 1 : 0 }}>
                      {charCount} chars
                    </motion.div>
                  </motion.div>

                  {/* Submit Button */}
                  <AnimatePresence mode="wait">
                    <motion.div key={status} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                      <MagneticButton
                        type="submit"
                        disabled={status === 'sending' || status === 'sent'}
                        className={`send-btn flex items-center justify-center gap-3 ${status === 'sending' ? 'sending' : status === 'sent' ? 'sent' : status === 'error' ? 'error' : ''}`}>
                        {status === 'idle' && (
                          <>
                            <motion.div animate={{ x: [0, 5, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
                              <Send className="w-5 h-5" />
                            </motion.div>
                            <span>{t.contact.send}</span>
                            <motion.span animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 2, repeat: Infinity }}>
                              🚀
                            </motion.span>
                          </>
                        )}
                        {status === 'sending' && (
                          <>
                            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                              className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                            <span>{t.contact.sending}</span>
                            <motion.span animate={{ y: [0, -5, 0] }} transition={{ duration: 0.5, repeat: Infinity }}>
                              ✈️
                            </motion.span>
                          </>
                        )}
                        {status === 'sent' && (
                          <>
                            <motion.div initial={{ scale: 0 }} animate={{ scale: [0, 1.3, 1] }} transition={{ duration: 0.5 }}>
                              <CheckCircle className="w-5 h-5" />
                            </motion.div>
                            <span>{t.contact.sent}</span>
                            <motion.span animate={{ rotate: [0, 20, -20, 0] }} transition={{ duration: 0.5, repeat: 3 }}>
                              🎉
                            </motion.span>
                          </>
                        )}
                        {status === 'error' && (
                          <>
                            <motion.div animate={{ x: [-3, 3, -3, 3, 0] }} transition={{ duration: 0.4 }}>
                              <AlertCircle className="w-5 h-5" />
                            </motion.div>
                            <span>{t.contact.error}</span>
                          </>
                        )}
                      </MagneticButton>
                    </motion.div>
                  </AnimatePresence>

                  {/* Trust indicators */}
                  <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
                    transition={{ delay: 0.5 }} className="flex flex-wrap items-center justify-center gap-4 pt-4">
                    {[
                      { icon: Shield, text: 'Secure & Private', emoji: '🔒' },
                      { icon: Headphones, text: '24h Response', emoji: '⚡' },
                      { icon: CheckCircle, text: 'Free Consultation', emoji: '✅' },
                    ].map((item, i) => (
                      <motion.div key={i}
                        whileHover={{ scale: 1.05 }}
                        className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full ${
                          dark ? 'bg-gray-800/50 text-gray-400' : 'bg-gray-50 text-gray-500'
                        }`}>
                        <span>{item.emoji}</span>
                        <span>{item.text}</span>
                      </motion.div>
                    ))}
                  </motion.div>
                </form>

                {/* Success overlay */}
                <AnimatePresence>
                  {status === 'sent' && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-green-500/10 to-emerald-500/10 backdrop-blur-sm rounded-3xl z-20 pointer-events-none">
                      <motion.div initial={{ scale: 0 }} animate={{ scale: [0, 1.2, 1] }} transition={{ duration: 0.6 }}
                        className="text-center">
                        <motion.div animate={{ y: [0, -10, 0] }} transition={{ duration: 1.5, repeat: Infinity }}
                          className="text-7xl mb-4">🎉</motion.div>
                        <div className="text-2xl font-bold gradient-text mb-2">{t.contact.sent}</div>
                        <div className={`text-sm ${dark ? 'text-gray-400' : 'text-gray-500'}`}>{t.contact.responseTime}</div>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </Tilt3DCard>

            {/* Quick action buttons below form */}
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: 0.6 }}
              className="grid grid-cols-2 gap-4 mt-6">
              <motion.a href="https://t.me/danieltsigu" target="_blank" rel="noopener noreferrer"
                whileHover={{ scale: 1.03, y: -3 }} whileTap={{ scale: 0.98 }}
                className={`rounded-2xl p-5 flex items-center gap-3 transition-all group ${dark ? 'bg-[#111127] border border-gray-800 hover:border-sky-500/30' : 'bg-white shadow-md hover:shadow-lg border border-gray-100'}`}>
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <TelegramIcon className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className={`font-bold text-sm ${dark ? 'text-gray-200' : 'text-gray-800'}`}>Telegram</div>
                  <div className={`text-xs ${dark ? 'text-gray-500' : 'text-gray-400'}`}>{t.contact.chatNow}</div>
                </div>
              </motion.a>

              <motion.a href="tel:+251986079581"
                whileHover={{ scale: 1.03, y: -3 }} whileTap={{ scale: 0.98 }}
                className={`rounded-2xl p-5 flex items-center gap-3 transition-all group ${dark ? 'bg-[#111127] border border-gray-800 hover:border-green-500/30' : 'bg-white shadow-md hover:shadow-lg border border-gray-100'}`}>
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className={`font-bold text-sm ${dark ? 'text-gray-200' : 'text-gray-800'}`}>Call Now</div>
                  <div className={`text-xs ${dark ? 'text-gray-500' : 'text-gray-400'}`}>0986079581</div>
                </div>
              </motion.a>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ===== FOOTER =====
function Footer({ t, dark }: { t: typeof translations.en; dark: boolean }) {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });

  return (
    <>
      <motion.div className="fixed top-0 left-0 right-0 h-1 z-[60] origin-left" style={{ scaleX, background: 'linear-gradient(90deg, #009B3A, #FCDD09, #EF2118, #6366f1)' }} />

      <footer className={`py-16 relative overflow-hidden ${dark ? 'bg-[#080816]' : 'bg-gray-900'} text-white`}>
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -right-20 w-60 h-60 rounded-full bg-indigo-500/5 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full bg-green-500/5 blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <motion.div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white font-bold text-xl shadow-lg"
                  whileHover={{ rotate: 360 }} transition={{ duration: 0.6 }}>D</motion.div>
                <div>
                  <div className="text-2xl font-bold gradient-text-neon">Daniel Tsigu</div>
                  <div className="text-gray-500 text-sm">ዳንኤል ፅጉ</div>
                </div>
              </div>
              <p className="text-gray-400 mb-6 leading-relaxed max-w-md">
                Full Stack Web Developer from Asella, Ethiopia 🇪🇹. Creating exceptional digital experiences with passion, innovation and modern technology.
              </p>
              <div className="flex gap-3">
                {[
                  { Icon: GithubIcon, href: 'https://github.com/danieltsigu' },
                  { Icon: LinkedinIcon, href: 'https://linkedin.com/in/danieltsigu' },
                  { Icon: TelegramIcon, href: 'https://t.me/danieltsigu' },
                  { Icon: Mail, href: 'mailto:danieltsigu49@gmail.com' },
                ].map(({ Icon, href }, i) => (
                  <motion.a key={i} href={href} target="_blank" rel="noopener noreferrer" whileHover={{ scale: 1.1, y: -3 }}
                    className="w-10 h-10 rounded-xl bg-gray-800 hover:bg-indigo-600 flex items-center justify-center transition-all">
                    <Icon className="w-4 h-4" />
                  </motion.a>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-lg">Quick Links</h3>
              <div className="space-y-3 text-gray-400">
                {['about', 'skills', 'projects', 'experience', 'contact'].map(link => (
                  <a key={link} href={`#${link}`} className="block hover:text-indigo-400 transition-colors capitalize hover-underline w-fit">{link}</a>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-lg">Contact</h3>
              <div className="space-y-3 text-gray-400 text-sm">
                <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-green-400" /><span>Asella, Ethiopia</span></div>
                <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-blue-400" /><a href="tel:+251986079581" className="hover:text-white transition-colors">0986079581</a></div>
                <div className="flex items-center gap-2"><Mail className="w-4 h-4 text-pink-400" /><a href="mailto:danieltsigu49@gmail.com" className="hover:text-white transition-colors text-xs">danieltsigu49@gmail.com</a></div>
              </div>
            </div>
          </div>

          <div className="flex h-1 rounded-full overflow-hidden mb-8">
            <motion.div className="flex-1 bg-green-500" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }} />
            <motion.div className="flex-1 bg-yellow-400" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.2 }} />
            <motion.div className="flex-1 bg-red-500" initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.4 }} />
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">© {new Date().getFullYear()} Daniel Tsigu. {t.footer.rights}</p>
            <p className="text-gray-400 text-sm flex items-center gap-2">
              {t.footer.madeWith} <motion.span animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 1, repeat: Infinity }}><Heart className="w-4 h-4 text-red-500 fill-current" /></motion.span> {t.footer.fromEthiopia}
            </p>
          </div>
        </div>
      </footer>

      <BackToTopButton />
    </>
  );
}

// ===== BACK TO TOP =====
function BackToTopButton() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const h = () => setVisible(window.scrollY > 500);
    window.addEventListener('scroll', h);
    return () => window.removeEventListener('scroll', h);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.button initial={{ opacity: 0, scale: 0, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0, y: 20 }}
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-8 right-8 w-14 h-14 rounded-full bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 text-white flex items-center justify-center shadow-2xl z-50"
          whileHover={{ scale: 1.15, y: -5 }} whileTap={{ scale: 0.9 }}>
          <ArrowUp className="w-6 h-6" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}

// ===== LOADING SCREEN =====
function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) { clearInterval(timer); return 100; }
        return prev + 2;
      });
    }, 30);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0a0a1a] relative overflow-hidden">
      <div className="absolute inset-0">
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div key={i} className="absolute rounded-full" style={{
            left: `${(i * 3.7) % 100}%`, width: `${2 + (i % 3)}px`, height: `${2 + (i % 3)}px`,
            background: ['#009B3A', '#FCDD09', '#EF2118', '#6366f1', '#ec4899'][i % 5],
          }}
            animate={{ y: [800, -50], opacity: [0, 1, 0] }}
            transition={{ duration: 3 + (i % 3), repeat: Infinity, delay: (i * 0.15) % 3 }}
          />
        ))}
      </div>

      <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }}
        transition={{ type: 'spring', duration: 1 }} className="relative z-10">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          className="w-32 h-32 rounded-full border-4 border-transparent"
          style={{ borderTopColor: '#009B3A', borderRightColor: '#FCDD09', borderBottomColor: '#EF2118', borderLeftColor: '#6366f1' }} />
        <motion.div animate={{ rotate: -360 }} transition={{ duration: 5, repeat: Infinity, ease: 'linear' }}
          className="absolute inset-2 rounded-full border-2 border-transparent"
          style={{ borderTopColor: '#ec4899', borderRightColor: '#06b6d4', borderBottomColor: '#f59e0b' }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.span className="text-3xl font-black gradient-text-neon" animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}>DT</motion.span>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        className="mt-8 text-center z-10">
        <p className="text-2xl font-bold gradient-text-neon mb-1">Daniel Tsigu</p>
        <p className="text-gray-500 text-sm">ዳንኤል ፅጉ</p>

        <div className="w-48 h-1.5 bg-gray-800 rounded-full mt-6 overflow-hidden mx-auto">
          <motion.div className="h-full rounded-full" style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #009B3A, #FCDD09, #EF2118, #6366f1)' }} />
        </div>
        <p className="text-gray-600 text-xs mt-2 font-mono">{progress}%</p>

        <div className="flex gap-1.5 mt-4 justify-center">
          {[0, 1, 2, 3].map(i => (
            <motion.div key={i} className="w-2 h-2 rounded-full"
              style={{ background: ['#009B3A', '#FCDD09', '#EF2118', '#6366f1'][i] }}
              animate={{ y: [0, -15, 0], scale: [1, 1.3, 1] }}
              transition={{ duration: 0.7, repeat: Infinity, delay: i * 0.12 }} />
          ))}
        </div>
      </motion.div>
    </div>
  );
}

// ===== MAIN APP =====
function App() {
  const [lang, setLang] = useState<LangKey>('en');
  const [loading, setLoading] = useState(true);
  const [dark, setDark] = useState(false);
  const t = translations[lang];

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    document.body.classList.toggle('dark', dark);
  }, [dark]);

  if (loading) return <LoadingScreen />;

  return (
    <div className={`min-h-screen transition-colors duration-500 ${dark ? 'bg-[#0a0a1a] text-gray-100' : 'bg-white text-gray-900'}`}
      style={{ fontFamily: lang === 'am' ? "'Noto Sans Ethiopic', 'Inter', sans-serif" : undefined }}>
      <CustomCursor />
      <Navigation lang={lang} setLang={(l) => setLang(l as LangKey)} t={t} dark={dark} setDark={setDark} />
      <HeroSection t={t} lang={lang} dark={dark} />
      <AboutSection t={t} dark={dark} />
      <ServicesSection t={t} dark={dark} />
      <SkillsSection t={t} dark={dark} />
      <ProjectsSection t={t} dark={dark} />
      <ExperienceSection t={t} dark={dark} />
      <TestimonialsSection t={t} dark={dark} />
      <ContactSection t={t} dark={dark} />
      <Footer t={t} dark={dark} />
    </div>
  );
}

export default App;
